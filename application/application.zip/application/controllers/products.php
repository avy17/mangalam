<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('welcome_message');
	}

	public function fetch_products(){


		$this->load->model("crud_model");  
           $fetch_data = $this->crud_model->make_datatables();  
           $data = array();  


           foreach($fetch_data as $row)  
           {  
                $sub_array = array();  
                  
                $sub_array[] = $row->id;  
                $sub_array[] = $row->name;
                $sub_array[] = $row->hsn;  
                $sub_array[] = $row->rate;
                $sub_array[] = $row->unit;
                $sub_array[] = $row->gst;

                if($this->session->userdata('inv_no')){

                	$dataString = $row->id.'#'.$row->name.'#'.$row->rate.'#'.$row->hsn.'#'.$row->gst;

				$sub_array[] = "<a class='qty_add' href='#modal-form' data-target='#modal-form' data-id ='".$dataString."'
				 role='button' class='blue' data-toggle='modal'> Add to invoice #".print_r($this->session->userdata('inv_no'))."</a>";	
			 } 

                  
                $data[] = $sub_array;  
           }  
           $output = array(  
                "draw"                    =>     intval($_POST["draw"]),  
                "recordsTotal"          =>      $this->crud_model->get_all_data(),  
                "recordsFiltered"     =>     $this->crud_model->get_filtered_data(),  
                "data"                    =>     $data  
           );  
           echo json_encode($output);  
      }  

	

	public function add()
	{

		$this->load->model('General_Model');
		if ($this->input->server('REQUEST_METHOD') === "POST") {
  		$postData = $this->input->post();
  		//_print_r($postData);exit;

  		$this->form_validation->set_error_delimiters('<div class="danger">', '</div>');
  		$this->form_validation->set_rules('name', 'Name', 'trim|required');
  		$this->form_validation->set_rules('hsn', 'HSN', 'trim|required');
  		$this->form_validation->set_rules('gst', 'GST', 'trim|required');
  		$this->form_validation->set_rules('rate', 'Rate', 'trim|required');
  			

  		if ($this->form_validation->run() != FALSE)
  		{
  		

  			$id = $this->General_Model->insertDataByTable('products',$postData);			
  	

			redirect('products');




  	}
  }

			_getAdminLoadView('add_product');
	}

	public function ajaxSearch($val=null){

		//echo $val;exit();
		$sess = 0;
		$val = urldecode($val);
		$data = array();
		//echo json_encode($val);
		if($val != ''){
			$this->load->model('Products_Model');
			$data = $this->Products_Model->ajaxSearch(urldecode($val));
			//_print_r($data);exit();			
		}
		if($this->session->userdata('inv_no')){
			$sess = $this->session->userdata('inv_no');
	}

		$resultArr = array();
		$resultArr['dataArr'] = $data;
		$resultArr['sess'] = $sess;
		echo json_encode($resultArr);
		//_getAdminLoadView('products2',$data);

	}



	public function show()
	{
		$this->load->model('Products_Model');
		$data['prod_data'] = $this->Products_Model->getAllProducts();
		//$this->load->view('header');
		_getAdminLoadView('products',$data);

	}

		public function delete($id=null)
	{
		$this->load->model('Products_Model');
		$this->Products_Model->deleteData($id);
		redirect('products');

	}

	public function edit($pro_id){


		$this->load->model('General_Model');

		$data['resultArr'] = $this->General_Model->getDataByid('products',$pro_id);

		//_print_r($resultArr);exit();


			if ($this->input->server('REQUEST_METHOD') === "POST") {
  		$postData = $this->input->post();
  		//_print_r($postData);exit;

  		$this->form_validation->set_error_delimiters('<div class="danger">', '</div>');
  		$this->form_validation->set_rules('name', 'Name', 'trim|required');
  		$this->form_validation->set_rules('hsn', 'HSN', 'trim|required');
  		$this->form_validation->set_rules('gst', 'GST', 'trim|required');
  		$this->form_validation->set_rules('rate', 'Rate', 'trim|required');
  			

  		if ($this->form_validation->run() != FALSE)
  		{
  		

  			$id = $this->General_Model->updateData('products',$pro_id,$postData);			
  	
			redirect('products');
  	}
  }



		_getAdminLoadView('edit_product',$data);


	}

	public function add_to_invoice($p_data = null){

		//error_reporting(1);
		$dataArr = explode('_',$p_data);

		$this->load->model('Products_Model');
		$this->load->model('General_Model');
		$inv_data = $this->General_Model->getDataByCond('invoice',array('invoice_no' => $this->session->userdata('inv_no')));

		
		
				$data = array(
        'product_id'      => $dataArr[0],
        'invoice_id'      => $inv_data[0]['id'],
        'qty'     => $dataArr[1],
        'price'   => $dataArr[2],
        'discount' => $dataArr[3]
        
        
);


		$insert_id = $this->Products_Model->insertDataByTable('invoice_items',$data);

		$this->Products_Model->updateData('products',$dataArr[0],['rate'=>$dataArr[2]]);


		print_r($insert_id);

		

		
	}




}
