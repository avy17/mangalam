<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->show();
		//$this->load->view('customer_list');
	}

	public function pdftest(){
		$html = '<html>
				<head></head>
				<body>
					<h1>HELLO WORLD!</h1>
				</body>
				</html>
				';
		
		$pdf_filename  = 'report.pdf';
		$this->load->library('dompdf_lib');
		$this->dompdf_lib->convert_html_to_pdf($html, $pdf_filename, true);
	}

	public function show()
	{
		$this->load->model('General_Model');
		$data['prod_data'] = $this->General_Model->getAllData('customer');
		//$this->load->view('header');
		_getAdminLoadView('customer_list',$data);

	}


public function delete_item($id){

	$this->load->model('General_Model');

		$resultArr = $this->General_Model->getDataByCond('customer',array('id' => $id));
		$data['prod_data'] = $resultArr[0];


		//_print_r($data['prod_data']);exit();
		$this->General_Model->deleteDatabyTable($data['prod_data']['id'],'customer');

		redirect('customer');


	}

	public function add_normal(){

		$this->load->model('General_Model');
		if ($this->input->server('REQUEST_METHOD') === "POST") {
  		$postData = $this->input->post();
  		//_print_r($postData);exit;

  		$this->form_validation->set_error_delimiters('<div class="danger">', '</div>');
  		$this->form_validation->set_rules('name', 'Name', 'trim|required');
  		$this->form_validation->set_rules('address', 'Address', 'trim|required');
  		$this->form_validation->set_rules('pincode', 'Pincode', 'trim|required');

  		$this->form_validation->set_rules('city', 'City', 'trim|required');
  		$this->form_validation->set_rules('state', 'State', 'trim|required');
  		$this->form_validation->set_rules('gst_no', 'GST', 'trim');
  			

  		if ($this->form_validation->run() != FALSE)
  		{
  		

  			$id = $this->General_Model->insertDataByTable('customer',$postData);
  			

  		
		

		redirect('customer');




  	}
  }

		_getAdminLoadView('add_customer');


	}



	public function add($inv_no=null, $date = null ){

		$this->load->model('General_Model');
		if ($this->input->server('REQUEST_METHOD') === "POST") {
  		$postData = $this->input->post();
  		//_print_r($postData);exit;

  		$this->form_validation->set_error_delimiters('<div class="danger">', '</div>');
  		$this->form_validation->set_rules('name', 'Name', 'trim|required');
  		$this->form_validation->set_rules('address', 'Address', 'trim|required');
  		$this->form_validation->set_rules('pincode', 'Pincode', 'trim|required');

  		$this->form_validation->set_rules('city', 'City', 'trim|required');
  		$this->form_validation->set_rules('state', 'State', 'trim|required');
  		$this->form_validation->set_rules('gst_no', 'GST', 'trim');
  			

  		if ($this->form_validation->run() != FALSE)
  		{
  		

  			$id = $this->General_Model->insertDataByTable('customer',$postData);
  			$date = date('Y-m-d',strtotime($date));
  			$this->General_Model->insertDataByTable('invoice',array('invoice_no' => $inv_no,'customer_id' => $id , 'date' => $date ));
  			if($this->session->userdata('inv_no') && $this->session->userdata('inv_id')){ 
			$this->session->unset_userdata('inv_no');
			$this->session->unset_userdata('inv_id');
		}

  		
		$this->session->set_userdata('inv_no',$inv_no);

		$inv_data = $this->General_Model->getDataByCond('invoice',array('invoice_no' => $this->session->userdata('inv_no')));

		$this->session->set_userdata('inv_id',$inv_data[0]['id']);

		redirect('products');




  	}
  }

		_getAdminLoadView('add_customer');


	}

		public function delete($id=null)
	{
		$this->load->model('Products_Model');
		$this->Products_Model->deleteData($id);
		redirect('products');

	}

	public function add_to_invoice($p_data = null){

		//echo 1;exit;

		//$p_data = $this->input->post('datastr');
		error_reporting(1);

		$dataArr = explode('_',$p_data);

		$this->load->model('Products_Model');

				$data = array(
        'product_id'      => $dataArr[0],
        'invoice_id'      => $this->session->userdata('inv_no'),
        'qty'     => $dataArr[1],
        'price'   => $dataArr[2]
        
        
);


		$insert_id = $this->Products_Model->insertDataByTable('invoice_items',$data);


		print_r($insert_id);

		

		
	}




}
