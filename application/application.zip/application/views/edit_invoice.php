<div class="page-content">

	<h1>
								Invoice #<?php echo $prod_data[0]['invoice_no']?>
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									
								</small>
							</h1>

							<h1>
								<div style="text-align: right"><a href="<?php echo base_url('invoice/add_more_items/').$prod_data[0]['invoice_id'].'/'.$prod_data[0]['invoice_no'] ?>"><button id="" type="button" class="btn btn-white btn-success">Add more items</button></a></div>	
								
							</h1>
	<div class="ace-settings-container" id="ace-settings-container">
			</div><!-- /.ace-settings-box -->
					</div><!-- /.ace-settings-container -->

						<div class="row">
									<div class="col-xs-12">
										
										<div class="clearfix">
											<div class="pull-right tableTools-container"></div>
										</div>

										<!-- div.table-responsive -->

										<!-- div.dataTables_borderWrap -->
										<div>
											<table id="simple-table" class="table table-striped table-bordered table-hover">
												<thead>
													<tr>
														<th class="center">
															SNO.
														</th>
														<th>Product Name</th>
														<th>HSN/SAC</th>
														<th>GST Rate (%)</th>
														<th>QTY</th>
														<th>Unit Price</th>
														<th>Discount(%)</th>
														<th>Amount</th>
														<th>Action</th>
														

													</tr>
												</thead>

												<tbody>
													<?php 
													$sno = 0;
													foreach((array)$prod_data as $em){
														$sno++;

                    ?>
													<tr>
														<td class="center">
															<label class="pos-rel">
																<?php echo $sno?>
																</label>
														</td>

														<td><?php echo $em['product_name']?></td>
														<td><?php echo $em['hsn']?></td>
														<td><?php echo $em['gst'].'%'?></td>
														<td><?php echo $em['qty']?></td>
														<td><?php echo $em['price']?></td>
														<td><?php echo $em['discount']?></td>
														
														<td style="text-align: right;"><?php echo number_format($em['final_price'],2)?></td>
														<td>
														<div class="hidden-sm hidden-xs action-buttons">
																

																<a class="green" href="<?php echo base_url('invoice/edit_item/').$em['iid']  ?>">
																	<i class="ace-icon fa fa-pencil bigger-130"></i>
																</a>

				<a class="qty_add" href="<?php echo base_url('invoice/delete_item/').$em['iid']  ?>" role="button" class="blue" >Delete</a>		
				</div>
				</td>										
										
															
																				
																
															</div>
													</tr>

										
													
												<?php } ?>

												</tbody>
												</table>
											</div>

										
										</div><!-- /.modal-content -->
									</div><!-- /.modal-dialog -->
								</div>


								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->


								
		<!-- inline scripts related to this page -->

