<div class="page-content">
	<div class="ace-settings-container" id="ace-settings-container">
			</div><!-- /.ace-settings-box -->
					</div><!-- /.ace-settings-container -->

						<div class="page-header">
							<h1>
								Customers
								
							</h1>
						</div><!-- /.page-header -->


							<h1>
								<div style="text-align: right"><a href="<?php echo base_url('customer/add_normal') ?>"><button id="" type="button" class="btn btn-white btn-success">Add new</button></a></div>	
								
							</h1>
						

						<div class="row">
									<div class="col-xs-12">
										
										<div class="clearfix">
											<div class="pull-right tableTools-container"></div>
										</div>
									

										<!-- div.table-responsive -->

										<!-- div.dataTables_borderWrap -->
										<div>
											<table id="dynamic-table" class="table table-striped table-bordered table-hover">
												<thead>
													<tr>
														<th class="center">
															<label class="pos-rel">
																<input type="checkbox" class="ace" />
																<span class="lbl"></span>
															</label>
														</th>
														
														<th>Name</th>
														<th>Address</th>
														<th>Pin</th>

														<th>GST No.</th>
														<th>Contact</th>

														<th>Action</th>
													</tr>
												</thead>

												<tbody>
													<?php 
													foreach((array)$prod_data as $em){
                    ?>
													<tr>

														<td class="center">
															<label class="pos-rel">
																<input type="checkbox" class="ace" />
																<span class="lbl"></span>
															</label>
														</td>

														
														<td><?php echo $em['name']?></td>
														<td><?php echo $em['address']?></td>
														<td><?php echo $em['pincode']?></td>
														<td><?php echo $em['gst_no']?></td>
														<td><?php echo $em['contact']?></td>

														<td>
															<div class="hidden-sm hidden-xs action-buttons">
																<!-- <a class="blue" href="#">
																	<i class="ace-icon fa fa-search-plus bigger-130"></i>
																</a>

																<a class="green" href="#">
																	<i class="ace-icon fa fa-pencil bigger-130"></i>
																</a>

				<a class="qty_add" href="<?php echo base_url('invoice/create_invoice/').$em['id']?>"> Create invoice</a>				 -->								
										
														<a class="qty_add" href="<?php echo base_url('customer/delete_item/').$em['id']  ?>" role="button" class="blue" >Delete</a>	
																				
																
															</div> 	

														</td>
													</tr>

										
													
												<?php } ?>
												</tbody>
												</table>
											</div>

											<div class="modal-footer no-margin-top">
											

												<ul class="pagination pull-right no-margin">
													<li class="prev disabled">
														<a href="#">
															<i class="ace-icon fa fa-angle-double-left"></i>
														</a>
													</li>

													<li class="active">
														<a href="#">1</a>
													</li>

													<li>
														<a href="#">2</a>
													</li>

													<li>
														<a href="#">3</a>
													</li>

													<li class="next">
														<a href="#">
															<i class="ace-icon fa fa-angle-double-right"></i>
														</a>
													</li>
												</ul>
											</div>
										</div><!-- /.modal-content -->
									</div><!-- /.modal-dialog -->
								</div>

								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->



								
		<!-- inline scripts related to this page -->

