<style type="text/css">
    
.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    padding: 0px;
    line-height: 1.42857143;
    width: auto;
}

.table-bordered, .table-bordered>tbody>tr>td, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>td, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>thead>tr>th {
    border: 10px;
}

body {
    background-color: #E4E6E9;
    padding-bottom: 0;
    padding-left: 2px;
    font-family: 'Open Sans';
    font-size: 10px;
    color: #080000;
}

#gst{

    padding-right: 0px;

}

.middle{
    text-align:center;
}

.right{
    text-align:right;
}

.special{
    font-weight: bolder; font-size: 16px
}




</style>

<div class="page-content">
    <div class="ace-settings-container" id="ace-settings-container">
            </div><!-- /.ace-settings-box -->
                    </div><!-- /.ace-settings-container -->

                        <div class="row">
                                    <div class="col-xs-12">
                                        
                                        <div class="clearfix">
                                            <div class="pull-right tableTools-container"></div>
                                        </div>


                                        <div>
                                            <table border="1" id="simple-table" class="table table-striped table-bordered table-hover">
                                                <caption class="special right">Original / Duplicate / Office Copy</caption>
                                                <thead>
                                                    <tr>
                                                        <th></th>
                                                        <th style="text-align: right;">Invoice #<?php echo $prod_data[0]['invoice_no']; ?>
                                                        &nbsp
                                                            

                                                            Date: <?php echo date('d-M-Y',strtotime($prod_data[0]['date']))?>   


                                                        </th>
                                                        <th style="text-align: right;">Buyer</th>
                                                        

                                                    </tr>
                                                </thead>

                                                <tbody>
            
                                                    <tr>
                                                        <td  style="text-align: left;">

                                                        <img id="logo" width="70px" height="70px" style="text-align: center" src="<?php echo base_url('cosmatics/img/swastik1.jpg') ?>">    
                                                            
                                                        </td>
                                                        
                                                        <td  style="text-align: right;">

                                                            <span class="special" style="">MANGALAM ENTERPRISES</span> <br>
                                                            <i class="fa fa-home"> Flat No. 504 Block L1 Silverline Apartments <br> Opp. BBD University Chinhat Lucknow- 226028</i><br>
                                                            <strong>GST: </strong> 09AASHA2540R1ZO
                                                            <br>
                                                            <strong>Contact: </strong> 9118212373

                                                            
                                                        </td>

                                                        <td style="text-align: right;"><span class="special" ><?php echo $prod_data[0]['customer_name'] ?></span>
                                                            <br>
                                                            <?php echo $prod_data[0]['address'] ?>


                                                            <br>
                                                            <strong>GST: </strong> <?php echo $prod_data[0]['gst_no'] ?>

                                                            <br>
                                                            <?php echo $prod_data[0]['contact'] ?>

                                                            <br>
                                                            <?php echo $prod_data[0]['email'] ?>

                                                        </td>
                                                        

                                                    </tr>

                                        
                                                    
                                                

                                                </tbody>
                                                </table>
                                            </div>
                                    

                                        <!-- div.table-responsive -->

                                        <!-- div.dataTables_borderWrap -->
                                        <div>
                                            <table id="simple-table" class="table table-striped table-bordered table-hover">
                                                <thead>
                                                    <tr>
                                                        <th class="center">
                                                            SNO.
                                                        </th>
                                                        <th>Product Name</th>
                                                        <th>HSN/SAC</th>
                                                        <th class="middle">GST(%)</th>
                                                        <th>QTY</th>
                                                        <th class="right">Rate</th>
                                                        <th class="middle">per</th>
                                                        <th class="right">Disc.<br>(%)</th>
                                                        <th class="right">Amount</th>
                                                        

                                                    </tr>
                                                </thead>

                                                <tbody>
                                                    <?php 
                                                    $sno = 0;
                                                    foreach((array)$prod_data as $em){
                                                        $sno++;

                    ?>
                                                    <tr>
                                                        <td class="center">
                                                           
                                                                <?php echo $sno?>
                                                               
                                                        </td>

                                                        <td><strong><?php echo $em['product_name']?></strong></td>
                                                        <td><?php echo $em['hsn']?></td>
                                                        <td class="middle"><?php echo $em['gst'].'%'?></td>
                                                        <td><?php echo $em['qty']?></td>
                                                        <td class="right"><?php echo number_format($em['price'],2)?></td>
                                                        <td class="middle"><?php echo $em['unit']?></td>
                                                        <td class="right"><?php echo $em['discount']?></td>
                                                        
                                                        <td style="text-align: right;"><strong><?php echo number_format($em['final_price'],2)?></strong></td>

                                                    </tr>

                                        
                                                    
                                                <?php } ?>

                                                </tbody>
                                                </table>
                                            </div>

                                        
                                        </div><!-- /.modal-content -->
                                    </div><!-- /.modal-dialog -->
                                </div>


                                                                    <div>
                                            <table caption="GST" id="" class="table table-striped table-bordered table-hover">
                                                <thead>
                                                    <tr>
                                                        <th class="center">
                                                                                                                    </th>
                                                        <th style="text-align: center;">GST Rate(%)</th>
                                                        <th class="right">Amount</th>
                                                        <th class="middle">CGST</th>
                                                        <th class="right">CGST<br>Amount</th>
                                                        <th class="middle">SGST</th>
                                                        <th class="right">SGST<br>Amount</th>
                                                        <th class="right">Net Tax</th>
                                                        

                                                    </tr>
                                                </thead>

                                                <tbody>
                                                    <?php 
                                                    $sno = 0;
                                                    foreach((array)$gst_data as $em){

                                                        //$sno++;

                    ?>
                                                    <tr>
                                                        <td class="center" id="gst">
                                                            <label class="pos-rel">
                                                                
                                                                </label>
                                                        </td>

                                                        <td style="text-align: center;"><strong>@<?php echo $em['gst'];  ?>%</strong></td>
                                                        <td class="right"><?php echo number_format($em['rate'],2);  ?> </td>
                                                        <td class="middle">@<?php echo  ($em['gst']/2);  ?>%</td>
                                                        <td class="right"><?php echo  number_format((((($em['rate'])*$em['gst'])/100)/2),2);  ?> </td>
                                                       <td class="middle">@<?php echo  ($em['gst']/2);  ?>%</td>
                                                        <td class="right"><?php echo number_format((((($em['rate'])*$em['gst'])/100)/2),2);  ?> </td>
                                                        <td style="text-align: right;"><strong><?php echo number_format(((($em['rate'])*$em['gst'])/100),2);  ?> </strong></td>
<?php $sno+=  (($em['rate'])*($em['gst']/100));     ?>
                                                    </tr>

                                        
                                                    
                                                <?php  } ?>





                    <tr>
                        <td  colspan='7' style="text-align:right; padding-right:0px;color:#0931f3;">
                <?php echo "Total Before Tax:"?>


                        </td>
                        <td  colspan='1' style="text-align:right; padding-right:0px;color:#0931f3;">
                <?php echo number_format($gross_amt,2); ?>


                        </td>
                                                </tr>

                                                


                    <tr>
                        <td  colspan='7' style="text-align:right; padding-right:0px;color:#0931f3;">
                <?php echo "Total Tax Amount:" ?>


                        </td>

                        <td  colspan='1' style="text-align:right; padding-right:0px;color:#0931f3;">
                <?php echo number_format($sno,2); ?>
                        </td>
                                                </tr>

                                                    <tr>
                        <td  colspan='7' style="text-align:right; padding-right:0px;color:#0931f3;">
                <?php 
              
                echo "Round Off (-):" ?>


                        </td>

                            <td  colspan='1' style="text-align:right; padding-right:0px;color:#0931f3;">
                <?php 
                $amt = number_format(($gross_amt+$sno),2);
                $paise = explode('.', $amt);

                echo "0.".$paise[1];  ?>


                        </td>
                                                </tr>

                        <tr>
                                                </tr>
                    
                                                <tr>

    <td  colspan='4' style="text-align:left; padding-right:0px;font-weight: 50;">



        <span id="words" class="special" ></span>

            


                        </td>

                        <td  colspan='3' style="text-align:right; padding-right:0px;font-size: large;font-weight: 600;">

            <input type="hidden" id="amount" value="<?php echo  floor($gross_amt+$sno); ?>">        
        <span id=""><?php echo  "Total Amount:"?></span>       


                        </td>
                         <td  colspan='1' style="text-align:right; padding-right:0px;font-size: large;font-weight: 600;">

                    
        <span id=""><?php echo number_format(floor($gross_amt+$sno)); ?></span>       


                        </td>

                    </tr>
                                                </tbody>
                                                </table>
                                            </div>

                                <!-- PAGE CONTENT ENDS -->
                            </div><!-- /.col -->
                        </div><!-- /.row -->
                    </div><!-- /.page-content -->
                </div>
            </div><!-- /.main-content -->


                                
        <!-- inline scripts related to this page -->

